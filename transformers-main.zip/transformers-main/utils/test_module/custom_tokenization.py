from transformers import BertTokenizer


class CustomTokenizer(BertTokenizer):
    pass
